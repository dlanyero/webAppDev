
//console.log(process.argv);

for (i = 0; i < process.argv.length; ++i)
{
    console.log(process.argv[i]);
}
