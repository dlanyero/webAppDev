create table Person (
  person_id integer primary key,
  person_name varchar(30)
);

insert into Person values (1, 'Fred Jones');
insert into Person values (2, 'Alf Wilson');
