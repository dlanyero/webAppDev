> Todo app with Express.js

This is an example of create, read, update, delete web application built with Express.js v4.8.1

Login with username=frank, password=test
