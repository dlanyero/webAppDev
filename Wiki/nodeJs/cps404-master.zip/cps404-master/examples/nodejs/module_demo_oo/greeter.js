'use strict';

let greet = require("./greet-module");

let g = new greet.Greeter('George');

g.speak();
