// To execute this with docker:

// docker run -v $(pwd):/myapp node:latest node /myapp/hello.js

console.log("Hello, world!")
