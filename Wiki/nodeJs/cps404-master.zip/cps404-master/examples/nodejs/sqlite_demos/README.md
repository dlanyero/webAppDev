# NodeJS sqlite examples. 

To use these examples, first execute:

```
npm install
node createdb.js
```

## createdb.js

Creates a small database used by the rest of the examples

## sqlitedemo.js

A small demonstration of sqlite features

## app.js and user.js

A custom ORM example.

